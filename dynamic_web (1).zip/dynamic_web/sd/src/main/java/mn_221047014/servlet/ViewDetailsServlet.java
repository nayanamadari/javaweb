package sd.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sd.db.Student;
import sd.db.StudentDao2;

public class ViewDetailsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ViewDetailsServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	System.out.println("ViewDetailsServlet doGet() method called");

        try {
            String rollNumber = request.getParameter("rollNumber");

            StudentDao2 studentDAO = new StudentDao2();
            Student student = studentDAO.getStudentByRollNumber(rollNumber);

            if (student != null) {
                request.setAttribute("student", student);
                RequestDispatcher dispatcher = request.getRequestDispatcher("displaydetails.jsp");
                dispatcher.forward(request, response);
            } else {
                String errorMessage = "No student found with roll number: " + rollNumber;
                request.setAttribute("errorMessage", errorMessage);
                RequestDispatcher dispatcher = request.getRequestDispatcher("index.html");
                dispatcher.forward(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
