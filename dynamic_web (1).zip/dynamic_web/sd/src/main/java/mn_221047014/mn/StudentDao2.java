package sd.db;
import java.io.IOException;
import java.sql.*;
import java.util.*;

import sd.db.JDBCConnection;
import sd.db.Student;

public class StudentDao2 {
	Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	public Student getStudentByRollNumber(String rollNumber) throws SQLException, ClassNotFoundException, IOException {
	    Student student = null;
	    conn = JDBCConnection.getConnection();
	    PreparedStatement statement = conn.prepareStatement("SELECT * FROM student WHERE rollNumber = ?");
	    statement.setString(1, rollNumber);
	    ResultSet resultSet = statement.executeQuery();
	    if (resultSet.next()) {
	        String name = resultSet.getString("name");
	        String address = resultSet.getString("address");
	        String be_branch = resultSet.getString("be_branch");
	        
	        student = new Student(name, address,be_branch);
	    }
	    return student;
	}
}
