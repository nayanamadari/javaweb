package _221047014.main;
import java.util.Scanner;

import _221047014.Custumerimpl;
public class Application {
	public static void main(String[] args)throws Exception {
		 Custumerimpl customer=new Custumerimpl();
		  Scanner sc=new Scanner(System.in);
		  System.out.println("Enter your choice 1.Without Prepared Statement 2.Using prepared statement");
		 int n=sc.nextInt();
		  if(n==1) {
			  
			  customer.addcustomers();
		 }
		else if(n==2) {
			customer.addcustomersusingprepare();
		}
	 }
}