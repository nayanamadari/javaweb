package _221047014;
import java.beans.Statement;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
public class Custumerimpl {
	private static final String PROPERTIES_FILE = "db.properties";
	  Properties properties = new Properties();
	  Connection connection = null;
	    public void addcustomers() throws FileNotFoundException, IOException {
	    	 try  {
	    		 properties.load(new FileInputStream(PROPERTIES_FILE));
	        
	        // Connect to the database
	        connection = DriverManager.getConnection("jdbc:sqlserver://172.16.51.44;", properties);	       
	            Statement statement = (Statement) connection.createStatement();
	            String query = "SELECT id, name, age FROM customers WHERE age > 1 OR 1=1 ";
	            ResultSet resultSet = ((java.sql.Statement) statement).executeQuery(query);
	            while (resultSet.next()) {
	                int id = resultSet.getInt("id");
	                String name = resultSet.getString("name");
	                int age = resultSet.getInt("age");
	                System.out.println("Customer: id=" + id + ", name=" + name + ", age=" + age);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    public void addcustomersusingprepare() throws FileNotFoundException, IOException 
	    {
	    	try
	    	{
	    	properties.load(new FileInputStream(PROPERTIES_FILE));
	        
	        // Connect to the database
	        connection = DriverManager.getConnection("jdbc:sqlserver://172.16.51.44;", properties);
        
           
            String query = "SELECT id, name, age FROM customers WHERE age > ?";
            PreparedStatement statement1 = connection.prepareStatement(query);
            statement1.setInt(1, 18); // set the parameter value for the age predicate

            ResultSet resultSet = statement1.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int age = resultSet.getInt("age");
                System.out.println("Customer: id=" + id + ", name=" + name + ", age=" + age);
            }
            }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
}